son = int(input("Son kiriting: "))

for i in range(1, son + 1):
    print(i, end=" ")

for j in range(son - 1, 0, -1):
    print(j, end=" ")
