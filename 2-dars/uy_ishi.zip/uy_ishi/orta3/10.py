import math


a = float(input("Son kiriting: "))
ildiz = a ** 0.5
print("Ildiz:", int(ildiz))
