a = int(input("son kiriting: "))
b = int(input("son kiriting: "))
y = 0
for i in range(a,b+1):
    y +=i

print(y)