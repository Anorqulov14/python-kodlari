son = int(input("son kiriting: "))

y = 1

for i in range(son,1,-1):
    y *= i

print(y)