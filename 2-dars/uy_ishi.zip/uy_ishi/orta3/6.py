son = int(input("son kiriting: "))

for i in range(son,son*2+1):

    print(i, end=" ") 