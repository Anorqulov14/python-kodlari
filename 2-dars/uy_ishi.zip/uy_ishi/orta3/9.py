son = int(input("son kiriting: "))
son1 = int(input("son kiriting: "))
print(son**son1)