son1 = int(input("son kiriting: "))
son2 = int(input("son kiriting: "))

for i in range(son1,son2+1):
    i = i * 2
    teskari = str(i)[::-1]
    print(teskari)