son1 = int(input("son kiriting: "))
son2 = int(input("son kiriting: "))
son3 = int(input("son kiriting: "))

y = 0
for i in range(son1+son3,son2+1+son3):
    y += i
print(y)