gap = input("soz kiriting: ")
tupe = []
for i in gap:
    tupe.append(i)
print(tupe)