lst = [1,2,3,4]
soz = "xa"
harflar = []
for i in lst:
    harflar.append(i)
print(harflar)